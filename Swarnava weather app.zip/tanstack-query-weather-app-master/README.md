# Weather App with Next JS, React, Tanstack Query, Shadcn UI, Recharts, Tailwind, Typescript Tutorial 🔥🔥
## https://youtu.be/BCp_5PoKrvI

![klimate](https://github.com/user-attachments/assets/03aed8a9-f2e1-4fcf-8628-5d1abd0c678c)

### Make sure to create a `.env` file with following variables -

```
VITE_OPENWEATHER_API_KEY=
```
